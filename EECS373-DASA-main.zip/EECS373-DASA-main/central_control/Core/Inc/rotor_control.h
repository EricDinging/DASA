#ifndef INC_rOTOR_CONTROL_H_
#define INC_rOTOR_CONTROL_H_

#include "main.h"

extern TIM_HandleTypeDef htim4;
extern TIM_HandleTypeDef htim1;

void rotor_control (uint8_t mode);



#endif /* INC_rOTOR_CONTROL_H_ */
